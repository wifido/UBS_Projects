#       20061127        Chris Janes
                                @SourceKey=$SourceKey
                                @RemData1=$RemData1
                                @RemData2=$RemData2
#       20061127
http://xstm1979dap.stm.swissbank.com/AELView?filter=�Class=999999�&view=basic