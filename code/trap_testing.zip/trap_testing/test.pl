#!/sbcimp/run/pd/perl/5.8.3/bin/perl -w



use SNMP_util;


